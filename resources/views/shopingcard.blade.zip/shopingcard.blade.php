
<?php

use App\Http\Controllers\HomeController;
use App\Register;
use App\Models\Addproduct;
use App\Models\card;

$total = 0;
if (Session::has('userId')) {
    $user = Register::where('id', '=', Session::get('userId'))->first();
    $user_id = $user->id;
    $user_name = $user->name;
    $total = card::where('user_id', '=', $user_id)->count();
    // // $total=HomeController::cardItem();
}

?>    


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap 5 CSS -->
    <link href="{{url('css/font-awesome.css')}}" rel="stylesheet">
    <!-- Bootstrap -->
    <!-- <link href="{{url('css/bootstrap.css')}}" rel="stylesheet"> -->
    <!-- SmartMenus jQuery Bootstrap Addon CSS -->
    <link href="{{url('css/jquery.smartmenus.bootstrap.css')}}" rel="stylesheet">
    <!-- Product view slider -->
    <link rel="stylesheet" type="text/css" href="{{url('css/jquery.simpleLens.css')}}">
    <!-- slick slider -->
    <link rel="stylesheet" type="text/css" href="{{url('css/slick.css')}}">
    <!-- price picker slider -->
    <link rel="stylesheet" type="text/css" href="{{url('css/nouislider.css')}}">
    <!-- Theme color -->
    <link id="switcher" href="{{url('css/theme-color/default-theme.css')}}" rel="stylesheet">
    <!-- <link id="switcher" href="css/theme-color/bridge-theme.css" rel="stylesheet"> -->
    <!-- Top Slider CSS -->
    <link href="{{url('css/sequence-theme.modern-slide-in.css')}}" rel="stylesheet" media="all">

    <!-- Main style sheet -->
    <link href="{{url('css/style.css')}}" rel="stylesheet">
    <link href="{{url('css/myStyle.css')}}" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <title>Document</title>
    <style>
        .passerrmsg,.adderr,.nameerr,.emailerr,.paymenterr{
            color: red;
            font-size: 14px;
            text-transform: capitalize;
            display: none;
            margin-left: 20px;  
            
        }
        #plusIcon {
            margin-top: 16px;
            display: inline;
            float: right;
            margin-right: -93px;
        }

        #buyItem {
            margin-top: 16px;
            margin-left: 46px;
        }

        #button-addon2 {
            margin-top: -61px;
        }

        aside {
            width: 350px;
            height: 367px;
        }

        #card-img {
            height: 93%;
            width: 93%;
            border-radius: .5rem;
            transition: .3s ease;
            margin: 15px;
        }
#check{
    margin-top: 30px;
    margin-left: 100px;
}
#aa-header .aa-header-bottom{
    background-color: #dff0d8;
    padding: 0px 0px;
  }
  
  
  /* loader */
  .input-box.button input #button{
  display:block;
  margin:20px auto;
  padding:10px 30px;
  background-color:#eee;
  border:solid #ccc 1px;
  cursor: pointer;
}
#overlayss{	
    /* top: 0; */
    z-index: 100;
     width: 100%;
    /*height: 100%; */
    display: none;
    margin-left: 272px;
    margin-top: -47px;
}
.cv-spinnerss {
  /* height: 100%; */
  display: flex;
  justify-content: center;
  align-items: center;  
}
.spinnerss {
  width: 40px;
  height: 40px;
  border: 4px #ddd solid;
  border-top: 4px #2e93e6 solid;
  border-radius: 50%;
  animation: sp-anime 0.8s infinite linear;
}
@keyframes sp-anime {
  100% { 
    transform: rotate(360deg); 
  }
}
.is-hide{
  display:none;
}

.input-box.button input #button{
  display:block;
  margin:20px auto;
  padding:10px 30px;
  background-color:#eee;
  border:solid #ccc 1px;
  cursor: pointer;
 

}
#overlay{	
    /* top: 0; */
    z-index: 100;
     width: 100%;
    /*height: 100%; */
    display: none;
    margin-left: -155px;
    margin-top: -47px;
}
.cv-spinner {
  /* height: 100%; */
  display: flex;
  justify-content: center;
  align-items: center;  
}
.spinner {
  width: 40px;
  height: 40px;
  border: 4px #ddd solid;
  border-top: 4px #2e93e6 solid;
  border-radius: 50%;
  animation: sp-anime 0.8s infinite linear;
}
@keyframes sp-anime {
  100% { 
    transform: rotate(360deg); 
  }
}
.is-hide{
  display:none;
}


/* hold css */

.input-box.button input #button{
  display:block;
  margin:20px auto;
  padding:10px 30px;
  background-color:#eee;
  border:solid #ccc 1px;
  cursor: pointer;
}
#overlay_hold{	
    /* top: 0; */
    z-index: 100;
     width: 100%;
    /*height: 100%; */
    display: none;
    margin-left: 272px;
    margin-top: -47px;
}
.cv-spinner_hold {
  /* height: 100%; */
  display: flex;
  justify-content: center;
  align-items: center;  
}
.spinner_hold {
  width: 40px;
  height: 40px;
  border: 4px #ddd solid;
  border-top: 4px #2e93e6 solid;
  border-radius: 50%;
  animation: sp-anime 0.8s infinite linear;
}
@keyframes sp-anime {
  100% { 
    transform: rotate(360deg); 
  }
}
.is-hide{
  display:none;
}

    </style>
</head>

<body>
<header id="aa-header">
        <!-- start header top  -->
        <div class="aa-header-top">
            <div class="container">
                <div class="row ">
                    <div class="col-md-12">
                        <div class="aa-header-top-area">
                            <!-- start header top left -->
                            <div class="aa-header-top-left">
                                <!-- start language -->
                                <div class="aa-language">
                                </div>
                                <!-- start cellphone -->
                                <div class="cellphone hidden-xs">

                                </div>
                                <!-- / cellphone -->
                            </div>
                            <!-- / header top left -->
                            <div class="aa-header-top-right">
                                <ul class="aa-head-top-nav-right">
                                    <li><a href="/register">My Account</a></li>
                                    <li class="hidden-xs"><a href="wishlist.html">Wishlist</a></li>
                                    <li class="hidden-xs"><a href="cart.html">My Cart</a></li>
                                    <li class="hidden-xs"><a href="checkout.html">Checkout</a></li>
                                    <li class="dropdown">
                                        @if(Session::has('userId'))
                                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">{{$user_name}}
                                            <!-- <span class="caret"></span> -->
                                        </a>
                                        <ul class="dropdown-menu">
                                            <li><a href="/logout">Logout</a></li>
                                        </ul>
                                    </li>
                                    @else
                                    <li><a href="/login">Login</a></li>
                                    @endif
                                    <!-- <li><a href="" data-toggle="modal" data-target="#login-modal">Login</a></li> -->
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- / header top  -->

        <!-- start header bottom  -->
        <div class="aa-header-bottom fixed-top" id="heade">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="aa-header-bottom-area">
                            <!-- logo  -->
                            <div class="aa-logo">
                                <!-- Text based logo -->
                                <a href="/">
                                    <span class="fa fa-shopping-cart"></span>
                                    <p>daily<strong>Shop</strong> <span>Your Shopping Partner</span></p>
                                </a>
                                <!-- img based logo -->
                                <!-- <a href="index.html"><img src="img/logo.jpg" alt="logo img"></a> -->
                            </div>
                            <!-- / logo  -->
                            <!-- cart box -->
                            <!-- <div class="aa-cartbox">
                                <a class="aa-cart-link" href="/cardlist">
                                    <span class="fa fa-shopping-basket"></span>
                                    <span class="aa-cart-title">SHOPPING CART</span>
                                    <span class="aa-cart-notify">{{$total}}</span>
                                </a>

                            </div> -->
                            <!-- / cart box -->
                            <!-- search box -->
                            <div class="aa-search-box">
                                <form action="">    
                                    <!-- <input type="text" name="" id="" placeholder="Search here ex. 'Electronics' ">
                                    <button type="submit"><span class="fa fa-search"></span></button> -->
                                </form>
                            </div>
                            <!-- / search box -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- / header bottom  -->
    </header>
        <div class=" text-center">
            <!-- <h2>Checkout form</h2> -->
        </div>
        <div class="row">
       
            <div class="col-md-4 order-md-2 mb-4" style="margin-top: 30px;">
                <h4 class="d-flex justify-content-between align-items-center mb-3">
                    <span class="text-muted">Your cart</span>
                    <span class="badge badge-secondary badge-pill">3</span>
                </h4>
                @php $total=0; @endphp
                @foreach($data as $val)
              
                <ul class="list-group mb-3" style="margin-top: 80px;">
                    <li class="list-group-item d-flex justify-content-between lh-condensed">
                        <div>
                            <h6 class="my-0">Product name</h6>
                        </div>
                        <span class="text-muted">{{ $val->name }}</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between lh-condensed">
                        <div>
                            <h6 class="my-0">Product quantity</h6>
                        </div>
                        <span class="text-muted">{{ $val->quantity }}</span>
                    </li>
                    <!-- <li class="list-group-item d-flex justify-content-between lh-condensed">
                        <div>
                            <h6 class="my-0">Third item</h6>
                        </div>
                        <span class="text-muted">$5</span>
                    </li> -->
                    <li class="list-group-item d-flex justify-content-between bg-light">
                        <div class="text-success">
                        <h6 class="my-0">Total</h6>
                        </div>
                        <strong>₹{{ $val->price * $val->quantity }}</strong>
                        <input type="hidden" name="price" id="price" value="{{ $val->price * $val->quantity  }}">

                    </li>
                </ul>
                @php $total += $val->price * $val->quantity; @endphp
                @endforeach
                <div id="grand-total-detail" class="payable-amount row"><span class="col-8">Grand Total</span>
                <span id="grand-total-amount-detail" class="col-4 text-right fw6">
                    <input type="hidden" id="totalprice_get" value="{{ $total }}">
                <span class="price" id="totalprice">₹{{ $total }}</span>
                </span>
            </div>
                <!-- <form class="card p-2" >
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Promo code">
                        <div class="input-group-append">
                            <button type="submit" class="btn btn-secondary">Redeem</button>
                        </div>
                    </div>
                </form> -->
            </div>
            <div class="col-md-6 order-md-1" id="check" style="margin-top: 100px;">
                <h4 class="mb-3">Billing address</h4>

                <!-- novalidate -->

                <form class="needs-validation" id="checkForm" >
                    @csrf
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="firstName">First name</label>
                            @foreach($data as $val)
                            <input type="hidden" id="quantity_get" name="quantity_get[]" value="{{$val->quantity}}">
                            <input type="hidden" id="prodcut_id_get" name="prodcut_id_get[]" value="{{$val->prodcut_id_get}}">
                            @endforeach
                            <input type="hidden" id="quantity_get" name="status[]" value="paid">
                            <input type="text" class="form-control" id="firstName" name="firstName" placeholder="" value="">
                            <span class="nameerr"> *this field is required </span>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="lastName">Last name</label>
                            <input type="text" class="form-control" id="lastName" name="lastName"placeholder="" value="">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="username">Username <span class="text-muted">(Optional)</span></label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">@</span>
                            </div>
                            <input type="text" class="form-control" id="username" name="username" placeholder="Username" >
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="email">Email </label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="you@example.com">
                        <span class="emailerr"> *this field is required </span>
                    </div>

                    <div class="mb-3">
                        <label for="address">Address</label>
                        <input type="text" class="form-control" id="address"  name="address" placeholder="1234 Main St">
                        <span class="adderr"> *this field is required </span>
                    </div>

                    <div class="mb-3">
                        <label for="address2">Address 2 <span class="text-muted">(Optional)</span></label>
                        <!-- <input type="hidden" class="form-control"  value="{{$val->quantity}}" name="quantity[]" placeholder="Apartment or suite"> -->
                        <input type="text" class="form-control" id="address2" name="address2" placeholder="Apartment or suite">
                    </div>

                    <div class="row">
                        <!-- <div class="col-md-5 mb-3"> -->
                            <!-- <label for="country">Country</label>
                            <select class="custom-select d-block w-100" id="country" required>
                                <option value="">Choose...</option>
                                <option>United States</option>
                            </select>
                            <div class="invalid-feedback">
                                Please select a valid country.
                            </div> -->
                        <!-- </div> -->
                        <!-- <div class="col-md-4 mb-3"> -->
                            <!-- <label for="state">State</label>
                            <select class="custom-select d-block w-100" id="state" required>
                                <option value="">Choose...</option>
                                <option>California</option>
                            </select> -->
                            <!-- <div class="invalid-feedback">
                                Please provide a valid state.
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="zip">Zip</label>
                            <input type="text" class="form-control" id="zip" placeholder="" required>
                            <div class="invalid-feedback">
                                Zip code required.
                            </div>
                        </div> -->
                    </div>
                    <!-- <hr class="mb-4">
                    <div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input" id="same-address">
                        <label class="custom-control-label" for="same-address">Shipping address is the same as my billing address</label>
                    </div>
                    <div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input" id="save-info">
                        <label class="custom-control-label" for="save-info">Save this information for next time</label>
                    </div>
                    <hr class="mb-4"> -->
    <hr>
                    <h4 class="mb-3">Payment</h4>


                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="cc-name">Pay Now</label>
                            <input type="number" class="form-control" id="payment"  name="payment" placeholder="" >
                            <span class="paymenterr"> *total amount not matched</span>
                        </div>
                    </div>
                    <hr class="mb-4">
                    <button class="btn btn-primary btn-lg btn-block" type="submit">Place Order</button>
                </form>
                <div id="overlay">
                <div class="cv-spinner">
                    <span class="spinner"></span>
                </div>
                </div>
            </div>
        </div>

        <!-- <footer class="my-5 pt-5 text-muted text-center text-small">
            <p class="mb-1">© 2021 - 2045 Company Name</p>
            <ul class="list-inline">
                <li class="list-inline-item"><a href="#">Privacy</a></li>
                <li class="list-inline-item"><a href="#">Terms</a></li>
                <li class="list-inline-item"><a href="#">Support</a></li>
            </ul>
        </footer> -->
    </div>
</body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"> </script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>
<script>
    $("#checkForm").on('submit',function(e){
    
        e.preventDefault();
        var formvalue= new FormData(this);
        var firstName=$('#firstName').val();
        var email=$('#email').val();
        var address=$('#address').val();
        var payment=$('#payment').val();
        var price=$('#totalprice_get').val();

        if(firstName == ""){
            $('.nameerr').show();
        }else if(email ==""){
            $('.emailerr').show();
            $('.nameerr').hide();
        }else if(address==""){
            $('.adderr').show();
            $('.emailerr').hide();
            $('.nameerr').hide();
        }else if(!(payment == price)){ 
            $('.paymenterr').show();
            $('.adderr').hide();            
        }else{
            $('.adderr').hide();            
            $('.emailerr').hide();
            $('.nameerr').hide();
            $('.paymenterr').hide();
            $('#loader').show();
            $("#orderbtn"). attr("disabled", true);
            $("#overlay").fadeIn(300);
            $.ajax({
                url:"/order_place",
                type:'POST',
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                data:formvalue,
                processData:false,
                contentType:false,
                success:function(response){
                    console.log(response);
                        swal("Thank You...", "Your Order Purchase SuccesFully.", "success",);
                        $('#checkForm').trigger('reset');
                        $("#overlay").fadeOut(300);
                        window.location.href="http://127.0.0.1:8000/";
                        // window.top.close();
                        $('form').trigger('reset');
                        $("#checkForm").trigger('reset');
                 
                },
            })
        }

    })
</script>
</html>